@echo off
REM =========================================================================
REM  MEMOPOD 2.0 - Windows Native App Launcher
REM  Starts local background server and launches standalone window mode
REM =========================================================================

title MEMOPOD 2.0 Knowledge OS
cd /d "%~dp0"

REM Check if Python is installed on the user's system
python --version > nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [1/2] Starting MemoPod local bridge server...
    start /b python server.py > nul 2>&1
    timeout /t 1 /nobreak > nul
    set URL=http://localhost:8990/quick.html?app=1
) else (
    echo [INFO] Python not found. Launching zero-dependency native mode...
    set URL=file:///%~dp0quick.html?app=1
)

echo [2/2] Launching MemoPod in standalone native window...
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%URL%" --window-size=1040,680
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%URL%" --window-size=1040,680
) else if exist "%ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe" --app="%URL%" --window-size=1040,680
) else (
    start "" "%URL%"
)

exit
