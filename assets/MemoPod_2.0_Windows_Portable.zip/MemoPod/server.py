#!/usr/bin/env python3
"""
MEMOPOD 2.0 - Hyper-Advanced Native macOS Apple Notes Bridge Server
Serves static web files on port 8990 and bridges Apple Notes with:
- High-speed batch extraction
- Native 2-way deep link: Jump back to Apple Notes from MemoPod drawer
- Category & folder clustering
- Markdown ZIP Obsidian export
"""

import os
import sys
import json
import zipfile
import io
import base64
import tempfile
import subprocess
import http.server
import socketserver
import urllib.parse

PORT = 8990
DIRECTORY = os.path.dirname(os.path.abspath(__file__))


def get_apple_notes_folders():
    """Fetch folder names and note counts from macOS Apple Notes."""
    script = """
    tell application "Notes"
        set folderList to {}
        repeat with f in folders
            set fName to name of f
            set fCount to count of notes in f
            set end of folderList to fName & ":::" & fCount
        end repeat
        set AppleScript's text item delimiters to "|||"
        return folderList as string
    end tell
    """
    try:
        res = subprocess.check_output(["osascript", "-e", script], timeout=15).decode("utf-8").strip()
        folders = []
        for item in res.split("|||"):
            if ":::" in item:
                parts = item.split(":::")
                name = parts[0].strip()
                count = int(parts[1].strip())
                if name != "Recently Deleted":
                    folders.append({"name": name, "count": count})
        folders.sort(key=lambda x: x["count"], reverse=True)
        return folders
    except Exception as e:
        print(f"[ERROR] Failed to fetch folders: {e}")
        return []


def get_apple_notes_mtime():
    """Ultra-fast check on SQLite WAL/DB file modification time."""
    wal = os.path.expanduser("~/Library/Group Containers/group.com.apple.notes/NoteStore.sqlite-wal")
    db = os.path.expanduser("~/Library/Group Containers/group.com.apple.notes/NoteStore.sqlite")
    m1 = os.stat(wal).st_mtime if os.path.exists(wal) else 0
    m2 = os.stat(db).st_mtime if os.path.exists(db) else 0
    return max(m1, m2)


def get_recent_apple_notes(limit=5):
    """Fetch top recent notes with content for instant delta sync."""
    script = f"""
    tell application "Notes"
        set totalN to count of notes
        set maxN to {limit}
        if totalN < maxN then set maxN to totalN
        set nList to {{}}
        repeat with i from 1 to maxN
            set n to note i
            set nId to id of n
            set nTitle to name of n
            set nDate to modification date of n as «class isot» as string
            set nBody to plaintext of n
            set end of nList to nId & "<<<>>>" & nTitle & "<<<>>>" & nDate & "<<<>>>" & nBody
        end repeat
        set AppleScript's text item delimiters to "|||###|||"
        return (totalN as string) & "@@@COUNT@@@" & (nList as string)
    end tell
    """
    try:
        raw = subprocess.check_output(["osascript", "-e", script], timeout=8).decode("utf-8").strip()
        if "@@@COUNT@@@" not in raw:
            return 0, []
        count_part, notes_part = raw.split("@@@COUNT@@@")
        total_count = int(count_part.strip()) if count_part.strip().isdigit() else 0
        raw_notes = notes_part.split("|||###|||")
        
        parsed_items = []
        for r in raw_notes:
            if "<<<>>>" not in r:
                continue
            parts = r.split("<<<>>>")
            apple_id = parts[0].strip() if len(parts) > 0 else ""
            title = parts[1].strip() if len(parts) > 1 else "제목 없는 메모"
            date_str = parts[2].strip() if len(parts) > 2 else ""
            body = parts[3].strip() if len(parts) > 3 else ""

            todos = []
            for line in body.split("\n"):
                l_str = line.strip()
                if l_str.startswith("- [ ]") or l_str.startswith("[ ]"):
                    todos.append({"text": l_str.replace("- [ ]", "").replace("[ ]", "").strip(), "done": False})
                elif l_str.startswith("- [x]") or l_str.startswith("[x]") or l_str.startswith("- [X]"):
                    todos.append({"text": l_str.replace("- [x]", "").replace("- [X]", "").replace("[x]", "").replace("[X]", "").strip(), "done": True})

            summary_lines = [l.strip() for l in body.split("\n") if l.strip() and not l.strip().startswith("#")]
            summary = " ".join(summary_lines[:2])[:140]

            tags = ["apple-notes"]
            lower_body = body.lower()
            if any(w in lower_body for w in ["ai", "인공지능", "gpt", "gemini"]):
                tags.append("ai")
            if any(w in lower_body for w in ["business", "매출", "마케팅", "수익", "고객"]):
                tags.append("business")
            if any(w in lower_body for w in ["개발", "api", "코드", "python", "javascript"]):
                tags.append("tech")
            if any(w in lower_body for w in ["기획", "아이디어", "설계"]):
                tags.append("idea")

            category = "note"
            if "business" in tags: category = "business"
            elif "tech" in tags: category = "tech"
            elif "idea" in tags: category = "idea"

            item = {
                "id": "apple_" + apple_id.split("/")[-1] if "/" in apple_id else "apple_" + str(abs(hash(apple_id))),
                "appleId": apple_id,
                "title": title[:60],
                "summary": summary if summary else title,
                "content": body,
                "todos": todos,
                "tags": tags,
                "type": category,
                "folder": "LiveSync",
                "createdAt": date_str,
                "source": "apple-notes",
                "isLiveSynced": True
            }
            parsed_items.append(item)
            
        return total_count, parsed_items
    except Exception as e:
        print(f"[ERROR] get_recent_apple_notes failed: {e}")
        return 0, []


def open_note_in_apple_notes(apple_id=None, note_title=None):
    """Deep-link to Apple Notes and bring the note to the front."""
    try:
        if apple_id:
            script = f"""
            tell application "Notes"
                activate
                show note id "{apple_id}"
            end tell
            """
        elif note_title:
            escaped = note_title.replace('"', '\\"')
            script = f"""
            tell application "Notes"
                activate
                show note "{escaped}"
            end tell
            """
        else:
            return False

        subprocess.run(["osascript", "-e", script], timeout=5)
        return True
    except Exception as e:
        print(f"[ERROR] open_note_in_apple_notes failed: {e}")
        return False


def extract_notes_from_apple(target_folders=None, limit_per_folder=None, total_limit=None):
    """
    Extract notes from macOS Apple Notes and transform them to MemoPod structure with persistent Apple IDs.
    """
    folders_meta = get_apple_notes_folders()
    if target_folders:
        active_folders = [f for f in folders_meta if f["name"] in target_folders]
    else:
        active_folders = folders_meta

    all_items = []
    
    def infer_category(folder_name, title, content):
        f = folder_name.lower()
        if any(k in f for k in ["business", "마자", "부업", "금융", "보험"]):
            return "business"
        if any(k in f for k in ["html", "css", "api", "개발", "스테이블", "디퓨전"]):
            return "tech"
        if any(k in f for k in ["아이디어", "idea", "기획"]):
            return "idea"
        return "note"

    for folder in active_folders:
        folder_name = folder["name"]
        count = folder["count"]
        if count == 0:
            continue

        fetch_limit = count
        if limit_per_folder:
            fetch_limit = min(count, limit_per_folder)

        escaped_folder = folder_name.replace('"', '\\"')
        script = f"""
        tell application "Notes"
            set bFolder to folder "{escaped_folder}"
            set nList to {{}}
            set maxCount to {fetch_limit}
            set totalInFolder to count of notes in bFolder
            if maxCount > totalInFolder then
                set maxCount to totalInFolder
            end if
            repeat with i from 1 to maxCount
                set n to note i of bFolder
                set nId to id of n
                set nTitle to name of n
                set nDate to modification date of n as string
                set nBody to plaintext of n
                set end of nList to nId & "<<<>>>" & nTitle & "<<<>>>" & nDate & "<<<>>>" & nBody
            end repeat
            set AppleScript's text item delimiters to "|||###|||"
            return nList as string
        end tell
        """
        try:
            raw = subprocess.check_output(["osascript", "-e", script], timeout=35).decode("utf-8").strip()
            raw_notes = raw.split("|||###|||")
            for r in raw_notes:
                if "<<<>>>" not in r:
                    continue
                parts = r.split("<<<>>>")
                apple_id = parts[0].strip() if len(parts) > 0 else ""
                title = parts[1].strip() if len(parts) > 1 else "제목 없는 메모"
                date_str = parts[2].strip() if len(parts) > 2 else ""
                body = parts[3].strip() if len(parts) > 3 else ""

                # Extract todos
                todos = []
                for line in body.split("\n"):
                    l_str = line.strip()
                    if l_str.startswith("- [ ]") or l_str.startswith("[ ]"):
                        todos.append({"text": l_str.replace("- [ ]", "").replace("[ ]", "").strip(), "done": False})
                    elif l_str.startswith("- [x]") or l_str.startswith("[x]") or l_str.startswith("- [X]"):
                        todos.append({"text": l_str.replace("- [x]", "").replace("- [X]", "").replace("[x]", "").replace("[X]", "").strip(), "done": True})

                summary_lines = [l.strip() for l in body.split("\n") if l.strip() and not l.strip().startswith("#")]
                summary = " ".join(summary_lines[:2])[:140]
                if not summary:
                    summary = title

                category = infer_category(folder_name, title, body)
                tag_name = folder_name.lower().replace(" ", "-").replace("/", "-")

                tags = [tag_name, "apple-notes"]
                lower_content = (title + " " + body).lower()
                for kw, tag in [("ai", "ai"), ("b2b", "b2b"), ("마케팅", "marketing"), ("도메인", "domain"), ("디자인", "design"), ("api", "api"), ("growth", "growth")]:
                    if kw in lower_content and tag not in tags:
                        tags.append(tag)

                created_at = "2026-10-16"
                for yr in ["2026", "2025", "2024", "2023"]:
                    if yr in date_str:
                        created_at = f"{yr}-10-15"
                        break

                all_items.append({
                    "id": f"apple-{abs(hash(folder_name + title + apple_id))}",
                    "appleId": apple_id,
                    "type": category,
                    "title": title,
                    "content": body,
                    "summary": summary,
                    "todos": todos,
                    "tags": tags[:5],
                    "folder": folder_name,
                    "createdAt": created_at,
                    "source": "apple-notes"
                })

                if total_limit and len(all_items) >= total_limit:
                    return all_items

        except Exception as e:
            print(f"[WARN] Failed extracting notes from folder '{folder_name}': {e}")
            continue

    return all_items


def build_markdown_zip(items):
    """Build Obsidian-compatible zip bundle with YAML frontmatter."""
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for item in items:
            folder = item.get("folder", "Notes").replace("/", "-")
            title = "".join(c for c in item.get("title", "Untitled") if c.isalnum() or c in (" ", "-", "_", ".")).strip()[:50]
            if not title:
                title = "Note"
            filename = f"{folder}/{title}.md"

            frontmatter = f"""---
title: "{item.get('title', '')}"
date: {item.get('createdAt', '')}
folder: "{folder}"
tags: {json.dumps(item.get('tags', []))}
type: "{item.get('type', 'note')}"
source: "Apple Notes"
---

{item.get('content', '')}
"""
            zf.writestr(filename, frontmatter)

    zip_buffer.seek(0)
    return zip_buffer.getvalue()


class MemoPodHandler(http.server.SimpleHTTPRequestHandler):
    ALLOWED_ORIGINS = {
        "http://localhost:8990",
        "http://127.0.0.1:8990",
        "https://setupod.com",
        "http://setupod.com",
        "https://www.setupod.com",
        "http://www.setupod.com",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def send_cors_headers(self):
        origin = self.headers.get("Origin", "")
        if not origin or origin in self.ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin or "http://127.0.0.1:8990")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        else:
            self.send_header("Access-Control-Allow-Origin", "null")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        
        # 1. Folders endpoint
        if parsed.path == "/api/apple-notes/folders":
            folders = get_apple_notes_folders()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"success": True, "folders": folders}, ensure_ascii=False).encode("utf-8"))
            return

        # 1-1. Live status delta check endpoint
        if parsed.path == "/api/apple-notes/live-status":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                client_mtime = float(query.get("since_mtime", [0])[0])
            except Exception:
                client_mtime = 0.0

            current_mtime = get_apple_notes_mtime()

            # If client mtime matches current within 1ms, return 0-cost response without osascript
            if client_mtime > 0 and abs(current_mtime - client_mtime) < 0.001:
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({
                    "success": True,
                    "has_changes": False,
                    "mtime": current_mtime
                }).encode("utf-8"))
                return

            # File changed or initial poll: retrieve recent notes
            total_count, recent_notes = get_recent_apple_notes(limit=5)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({
                "success": True,
                "has_changes": True,
                "mtime": current_mtime,
                "total_count": total_count,
                "recent_notes": recent_notes
            }, ensure_ascii=False).encode("utf-8"))
            return

        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        content_length = int(self.headers.get("Content-Length", 0))
        body_bytes = self.rfile.read(content_length) if content_length > 0 else b"{}"
        try:
            body = json.loads(body_bytes.decode("utf-8"))
        except Exception:
            body = {}

        # 2. Sync endpoint
        if parsed.path == "/api/apple-notes/sync":
            target_folders = body.get("folders")
            limit_per_folder = body.get("limit_per_folder")
            total_limit = body.get("total_limit")

            print(f"[SYNC] Extracting Apple Notes: folders={target_folders}, total_limit={total_limit}")
            notes = extract_notes_from_apple(target_folders, limit_per_folder, total_limit)
            print(f"[SYNC] Extracted {len(notes)} notes.")

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"success": True, "count": len(notes), "items": notes}, ensure_ascii=False).encode("utf-8"))
            return

        # 3. Native deep link: Open note in macOS Apple Notes
        if parsed.path == "/api/apple-notes/open":
            apple_id = body.get("appleId")
            note_title = body.get("title")
            success = open_note_in_apple_notes(apple_id, note_title)

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"success": success}, ensure_ascii=False).encode("utf-8"))
            return

        # 4. Export Obsidian Markdown ZIP
        if parsed.path == "/api/apple-notes/export-zip":
            target_folders = body.get("folders")
            notes = extract_notes_from_apple(target_folders)
            zip_bytes = build_markdown_zip(notes)

            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="AppleNotes_Obsidian_Export.zip"')
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(zip_bytes)
            return

        # 5. Windows Notes Sync endpoint
        if parsed.path == "/api/windows-notes/sync":
            use_sample = body.get("sample", False)
            source_type = body.get("source", "all")
            notes = []

            try:
                from sync_windows_notes import extract_sticky_notes, extract_samsung_notes
            except Exception:
                extract_sticky_notes = lambda *args: []
                extract_samsung_notes = lambda *args: []

            if use_sample:
                notes = [
                    {
                        "id": "win_sample_1",
                        "title": "2026 하반기 신규 비즈니스 파이프라인 (윈도우 스티커 메모)",
                        "summary": "마자 스튜디오 결제 API 연동 및 셋업팟 145번째 3D 목업 툴 크몽 등록 과제.",
                        "content": "2026 하반기 신규 비즈니스 파이프라인\n- [ ] 마자 스튜디오 결제 API 연동\n- [ ] 셋업팟 145번째 3D 목업 툴 크몽 등록\n- [ ] 콜드메일 50건 발송",
                        "todos": [
                            {"text": "마자 스튜디오 결제 API 연동", "done": False},
                            {"text": "셋업팟 145번째 3D 목업 툴 크몽 등록", "done": False},
                            {"text": "콜드메일 50건 발송", "done": False}
                        ],
                        "tags": ["sticky-notes", "business", "setupod"],
                        "type": "business",
                        "theme": "Blue",
                        "createdAt": "2026-10-16 14:30:00",
                        "source": "sticky-notes"
                    },
                    {
                        "id": "win_sample_2",
                        "title": "AI 프롬프트 엔지니어링 메모 (삼성 노트)",
                        "summary": "Gemini 2.0 Flash와 옵시디언 그래프 연동 로직 검토 및 캔버스 60FPS 최적화 점검.",
                        "content": "AI 프롬프트 엔지니어링 메모\nGemini 2.0 Flash와 옵시디언 그래프 연동 로직 검토.\n- [ ] 캔버스 60FPS 최적화 점검",
                        "todos": [
                            {"text": "캔버스 60FPS 최적화 점검", "done": False}
                        ],
                        "tags": ["samsung-notes", "tech", "ai"],
                        "type": "tech",
                        "theme": "Purple",
                        "createdAt": "2026-10-16 11:20:00",
                        "source": "samsung-notes"
                    },
                    {
                        "id": "win_sample_3",
                        "title": "주말 루틴 및 개인 할 일 (윈도우 스티커 메모)",
                        "summary": "비타민 구매 및 책상 정리 완료 항목.",
                        "content": "주말 루틴 및 개인 할 일\n- [ ] 비타민 구매\n- [x] 책상 정리 완료",
                        "todos": [
                            {"text": "비타민 구매", "done": False},
                            {"text": "책상 정리 완료", "done": True}
                        ],
                        "tags": ["sticky-notes", "routine"],
                        "type": "idea",
                        "theme": "Yellow",
                        "createdAt": "2026-10-15 20:00:00",
                        "source": "sticky-notes"
                    }
                ]
            else:
                custom_db = body.get("db_path")
                samsung_dir = body.get("samsung_dir")
                if source_type in ("sticky", "all"):
                    notes.extend(extract_sticky_notes(custom_db))
                if source_type in ("samsung", "all"):
                    notes.extend(extract_samsung_notes(samsung_dir))

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"success": True, "count": len(notes), "items": notes}, ensure_ascii=False).encode("utf-8"))
            return

        # 6. Windows Notes File Upload endpoint (plum.sqlite or .sdocx)
        if parsed.path == "/api/windows-notes/upload":
            filename = body.get("filename", "notes.sqlite")
            data_b64 = body.get("data", "")
            notes = []

            try:
                from sync_windows_notes import extract_sticky_notes, extract_samsung_notes
                raw_bytes = base64.b64decode(data_b64)
                
                # Write to temp file
                suffix = os.path.splitext(filename)[1] or ".sqlite"
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tf:
                    tf.write(raw_bytes)
                    temp_path = tf.name

                try:
                    if suffix.lower() in [".sdocx", ".sdoc"]:
                        notes = extract_samsung_notes(temp_path)
                    else:
                        notes = extract_sticky_notes(temp_path)
                finally:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
            except Exception as e:
                print(f"[ERROR] Upload extraction failed: {e}")

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({"success": True, "count": len(notes), "items": notes}, ensure_ascii=False).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()


class ThreadingServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def run():
    # Bind strictly to 127.0.0.1 to prevent unauthorized access from local network
    with ThreadingServer(("127.0.0.1", PORT), MemoPodHandler) as httpd:
        print(f"=====================================================")
        print(f"🚀 MEMOPOD 2.0 Native macOS Bridge Server Active (Multi-Threaded)")
        print(f"👉 Local URL: http://127.0.0.1:{PORT} (Loopback Only)")
        print(f"🍏 Apple Notes Deep Link & Sync Ready")
        print(f"🔒 Security: Bound to 127.0.0.1 (Isolated from LAN/Wi-Fi)")
        print(f"=====================================================")
        httpd.serve_forever()


if __name__ == "__main__":
    run()
