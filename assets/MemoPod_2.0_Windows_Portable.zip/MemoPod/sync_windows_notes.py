#!/usr/bin/env python3
"""
MEMOPOD 2.0 - Windows Sticky Notes & Samsung Notes Universal Extractor
Cross-platform bridge extracting notes and checkboxes from:
1. Microsoft Windows Sticky Notes (plum.sqlite)
2. Samsung Notes (.sdocx zip packages)
Exports directly to MemoPod Knowledge Graph JSON or Obsidian Markdown Vault.
"""

import os
import sys
import re
import json
import sqlite3
import zipfile
import argparse
from datetime import datetime


def get_default_sticky_notes_path():
    """Returns the default Microsoft Sticky Notes SQLite path on Windows."""
    local_app_data = os.environ.get("LOCALAPPDATA")
    if not local_app_data:
        local_app_data = os.path.expanduser("~/AppData/Local")
    
    # Standard UWP Package Path for Sticky Notes
    return os.path.join(
        local_app_data,
        "Packages",
        "Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe",
        "LocalState",
        "plum.sqlite"
    )


def get_default_samsung_notes_path():
    """Returns default Samsung Notes sync directory on Windows."""
    user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
    possible_paths = [
        os.path.join(user_profile, "Documents", "Samsung Notes"),
        os.path.join(user_profile, "AppData", "Local", "Samsung", "Samsung Notes"),
        os.path.join(user_profile, "AppData", "Local", "Packages", "SAMSUNGELECTRONICSCO.LTD.SamsungNotes_wyx1rkqq8dn6r", "LocalState")
    ]
    for p in possible_paths:
        if os.path.exists(p):
            return p
    return possible_paths[0]


def strip_rtf(rtf_text):
    """Strips RTF control codes while preserving linebreaks and bullet checklists."""
    if not rtf_text:
        return ""
    if not rtf_text.startswith("{\\rtf"):
        return rtf_text.strip()

    # Remove font and color tables
    t = re.sub(r"\{\\fonttbl[^{}]*(\{[^{}]*\})*\}", "", rtf_text)
    t = re.sub(r"\{\\colortbl[^{}]*\}", "", t)
    # Line breaks and bullet points
    t = re.sub(r"\\par[d]?", "\n", t)
    t = re.sub(r"\\bullet\s*", "- [ ] ", t)
    # Remove control words
    t = re.sub(r"\\[a-zA-Z0-9]+(-?[0-9]+)? ?", "", t)
    t = re.sub(r"[{}]", "", t)
    return t.strip()


def parse_todos_and_summary(body_text):
    """Extracts checklists and 2-sentence summary."""
    lines = [l.strip() for l in body_text.split("\n") if l.strip()]
    todos = []
    clean_lines = []

    for line in lines:
        if line.startswith("- [ ]") or line.startswith("[ ]") or line.startswith("TODO:") or line.startswith("할일:"):
            txt = line.replace("- [ ]", "").replace("[ ]", "").replace("TODO:", "").replace("할일:", "").strip()
            todos.append({"text": txt, "done": False})
        elif line.startswith("- [x]") or line.startswith("[x]") or line.startswith("- [X]"):
            txt = line.replace("- [x]", "").replace("- [X]", "").replace("[x]", "").replace("[X]", "").strip()
            todos.append({"text": txt, "done": True})
        else:
            clean_lines.append(line)

    title = clean_lines[0] if clean_lines else (lines[0] if lines else "제목 없는 메모")
    if len(title) > 60:
        title = title[:60] + "..."

    summary = " ".join(clean_lines[:2])[:140] if clean_lines else title
    return title, summary, todos


def extract_sticky_notes(db_path=None):
    """Extracts all active sticky notes from plum.sqlite."""
    target_path = db_path or get_default_sticky_notes_path()
    if not os.path.exists(target_path):
        print(f"[WARN] Sticky Notes database not found at: {target_path}")
        return []

    conn = sqlite3.connect(target_path)
    cursor = conn.cursor()
    query = """
    SELECT Id, Text, CreatedAt, UpdatedAt, Theme 
    FROM Note 
    WHERE IsDeleted = 0 
    ORDER BY UpdatedAt DESC
    """
    try:
        cursor.execute(query)
        rows = cursor.fetchall()
    except Exception as e:
        print(f"[ERROR] Querying plum.sqlite failed: {e}")
        return []
    finally:
        conn.close()

    items = []
    theme_category_map = {
        "Blue": "business",
        "Purple": "tech",
        "Yellow": "idea",
        "Green": "link",
        "Pink": "note",
        "Charcoal": "tech",
        "Grey": "note"
    }

    for row in rows:
        n_id, raw_text, created_at, updated_at, theme = row
        clean_text = strip_rtf(raw_text or "")
        if not clean_text:
            continue

        title, summary, todos = parse_todos_and_summary(clean_text)
        category = theme_category_map.get(theme, "note")

        tags = ["sticky-notes"]
        lower = clean_text.lower()
        if any(w in lower for w in ["ai", "gemini", "gpt"]): tags.append("ai")
        if any(w in lower for w in ["business", "매출", "마케팅", "수익"]): tags.append("business")
        if any(w in lower for w in ["개발", "api", "python", "코드"]): tags.append("tech")
        if any(w in lower for w in ["아이디어", "기획"]): tags.append("idea")

        items.append({
            "id": f"win_sticky_{n_id}",
            "stickyId": n_id,
            "title": title,
            "summary": summary,
            "content": clean_text,
            "todos": todos,
            "tags": tags,
            "type": category,
            "theme": theme,
            "createdAt": str(updated_at or created_at or datetime.now().isoformat()),
            "source": "sticky-notes"
        })

    return items


def extract_samsung_notes(folder_path=None):
    """Extracts Samsung Notes from a folder containing .sdocx files."""
    target_dir = folder_path or get_default_samsung_notes_path()
    if not os.path.exists(target_dir):
        print(f"[INFO] Samsung Notes directory not found at: {target_dir}")
        return []

    items = []
    if os.path.isfile(target_dir):
        files_to_process = [(os.path.dirname(target_dir), os.path.basename(target_dir))]
    else:
        files_to_process = []
        for root, _, files in os.walk(target_dir):
            for f in files:
                if f.endswith(".sdocx") or f.endswith(".sdoc"):
                    files_to_process.append((root, f))

    for root, f in files_to_process:
        if f.endswith(".sdocx") or f.endswith(".sdoc"):
            file_path = os.path.join(root, f)
            try:
                with zipfile.ZipFile(file_path, "r") as zf:
                    content_text = ""
                    for name in zf.namelist():
                        if name.endswith("document.xml") or name.endswith("content.xml"):
                            raw_xml = zf.read(name).decode("utf-8", errors="ignore")
                            content_text = re.sub(r"<[^>]+>", "\n", raw_xml)
                            content_text = "\n".join(l.strip() for l in content_text.split("\n") if l.strip())
                            break
                        elif name.endswith(".json") and "content" in name:
                            raw_json = zf.read(name).decode("utf-8", errors="ignore")
                            try:
                                data = json.loads(raw_json)
                                content_text = json.dumps(data, ensure_ascii=False)
                            except Exception:
                                pass

                    if content_text:
                        mtime = os.path.getmtime(file_path)
                        date_str = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
                        title, summary, todos = parse_todos_and_summary(content_text)
                        safe_name = os.path.splitext(f)[0]

                        items.append({
                            "id": f"samsung_{abs(hash(safe_name))}",
                            "title": title or safe_name,
                            "summary": summary,
                            "content": content_text,
                            "todos": todos,
                            "tags": ["samsung-notes"],
                            "type": "note",
                            "source": "samsung-notes",
                            "createdAt": date_str
                        })
            except Exception as e:
                print(f"[WARN] Failed to parse {f}: {e}")

    return items


def run_self_test():
    """Generates a mock database to test Windows notes extraction on any platform."""
    print("🧪 Running Windows Notes self-test with in-memory database...")
    test_db = ":memory:"
    conn = sqlite3.connect(test_db)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE Note (
        Id TEXT PRIMARY KEY,
        Text TEXT,
        CreatedAt TEXT,
        UpdatedAt TEXT,
        Theme TEXT,
        IsDeleted INTEGER
    )
    """)
    sample_notes = [
        ("guid-101", "2026 하반기 신규 비즈니스 파이프라인\n- [ ] 마자 스튜디오 결제 API 연동\n- [ ] 셋업팟 145번째 3D 목업 툴 크몽 등록\n- [ ] 콜드메일 50건 발송", "2026-10-14 10:00:00", "2026-10-16 14:30:00", "Blue", 0),
        ("guid-102", "AI 프롬프트 엔지니어링 메모\nGemini 2.0 Flash와 옵시디언 그래프 연동 로직 검토.\n- [ ] 캔버스 60FPS 최적화 점검", "2026-10-15 09:00:00", "2026-10-16 11:20:00", "Purple", 0),
        ("guid-103", "주말 쇼핑 및 개인 메모\n- [ ] 비타민 구매\n- [x] 책상 정리 완료", "2026-10-12 18:00:00", "2026-10-15 20:00:00", "Yellow", 0)
    ]
    c.executemany("INSERT INTO Note VALUES (?,?,?,?,?,?)", sample_notes)
    conn.commit()

    # Query
    c.execute("SELECT Id, Text, CreatedAt, UpdatedAt, Theme FROM Note WHERE IsDeleted = 0")
    rows = c.fetchall()
    conn.close()

    print(f"✅ Self-test extracted {len(rows)} mock Windows notes successfully!")
    for r in rows:
        title, summary, todos = parse_todos_and_summary(r[1])
        print(f" - [{r[4]}] {title} (Todos: {len(todos)})")
    return True


def main():
    parser = argparse.ArgumentParser(description="MemoPod 2.0 Windows Notes Extractor")
    parser.add_argument("--test", action="store_true", help="Run self-test with mock data")
    parser.add_argument("--sticky-db", type=str, help="Custom path to plum.sqlite")
    parser.add_argument("--samsung-dir", type=str, help="Custom path to Samsung Notes folder")
    parser.add_argument("--export-json", type=str, help="Export extracted notes to JSON file")
    args = parser.parse_args()

    if args.test:
        run_self_test()
        return

    all_notes = []
    print("🔍 Scanning for Windows Sticky Notes...")
    sticky_notes = extract_sticky_notes(args.sticky_db)
    print(f"  └─ Extracted {len(sticky_notes)} Sticky Notes.")
    all_notes.extend(sticky_notes)

    print("🔍 Scanning for Samsung Notes (.sdocx)...")
    samsung_notes = extract_samsung_notes(args.samsung_dir)
    print(f"  └─ Extracted {len(samsung_notes)} Samsung Notes.")
    all_notes.extend(samsung_notes)

    print(f"🎉 Total extracted Windows notes: {len(all_notes)}")

    if args.export_json:
        with open(args.export_json, "w", encoding="utf-8") as f:
            json.dump(all_notes, f, ensure_ascii=False, indent=2)
        print(f"💾 Saved to {args.export_json}")


if __name__ == "__main__":
    main()
