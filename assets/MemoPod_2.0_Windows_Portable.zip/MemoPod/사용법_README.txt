=====================================================
  MEMOPOD 2.0 PRO - Windows Knowledge OS
=====================================================

[실행 방법]
1. 'MemoPod.bat' 파일을 더블 클릭합니다.
2. 크롬 또는 엣지(Edge)의 주소창 없는 독립 윈도우 창으로 즉시 실행됩니다.

[지원하는 윈도우 메모]
- Windows 기본 스티커 메모 (Sticky Notes)
- Samsung Notes (삼성 노트 .sdocx)
- 마크다운 및 옵시디언 볼트(Vault) 연동

문의: SETUPOD (https://setupod.com)
